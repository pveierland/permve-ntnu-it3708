#pragma once


#include <boost/gil/gil_all.hpp>

namespace vi
{
    namespace segment
    {






    }
}
